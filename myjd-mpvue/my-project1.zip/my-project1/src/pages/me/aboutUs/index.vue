<template>
  <div class="whole">
  <h2>开发：</h2>
    <h1>湖北大学教育学院16级教育技术学</h1>
    <h1>吴建星，陈美芳，黄强海</h1>
    <h2>运营发行：</h2>
    <h1>湖北滕飞有限公司</h1>
  </div>
</template>

<script>
  export default {
    name: 'index'
  }
</script>

<style scoped>
.whole {
  position: absolute;
  width: 100%;
  height: 100%;
  text-align: center;
  margin: 0 auto;
  background: linear-gradient(to bottom right, #bebbf3, #f8cdc4);
}
</style>
