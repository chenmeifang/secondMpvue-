<template>
  <div class="whole">
    <div class="displayBackground">
    <div class="displayRoom">
      <p class="header">{{ name }}</p>
      <div class="msg_room" v-for="(item, index) in allList"  :key="index">
        <div class="li1"><img class="userinfo-avatar-left" :src=ava v-if="(item.fromTo === sendId + '-' + myId)"></div>
        <div class="li2">
          <ul>
            <li class="time_room">{{ item.date }}</li>
            <li>{{ item.content }}</li>
          </ul>
        </div>
      <div class="li3"><img class="userinfo-avatar-right" :src=user.avatar v-if="(item.fromTo ===  myId +  '-' + sendId)"></div>
      </div>
      </div>
    </div>
    <div class="footer">
      <label><input type="text" v-model="msg"></label>
      <i-button i-class="i-button" type="primary" @click="sendMsg">发送</i-button>
    </div>
  </div>
</template>

<script>
  // fly,生命周期，时间格式化，数组合并，定时器，排序
  import { formatTime } from '../../../utils'

  export default {
    name: 'index',
    data () {
      return {
        ava: '',
        name: '',
        sendId: '',
        msg: '',
        reservedList: [],
        sendList: [],
        allList: [],
        reservedTimer: '',
        sendTimer: '',
        allTimer: '',
        myId: '',
        user: {}
      }
    },
    onLoad (option) {
      this.name = option.name
      this.sendId = option.toWho
      this.ava = option.ava
      this.myId = this.$store.state.userInformation.id
      this.user = this.$store.state.userInformation
    },
    onShow () {
      // 设置定时器，不断从服务器取得数据，轮询是一种性能比较差的方法
      this.reservedTimer = setInterval(this.getReserved, 200)
      this.sendTimer = setInterval(this.getSend, 200)
      this.allTimer = setInterval(this.handleList, 200)
    },
    onUnload () {
      clearInterval(this.reservedTimer)
      clearInterval(this.sendTimer)
      clearInterval(this.allTimer)
    },
    computed: {
      sortAllList () {
        return this.sortById(this.allList, 'id')
      }
    },
    methods: {
      sortById (array, key) {
        // 根据id排序，由于id自增，id排序等于时间排序
        return array.sort(function (a, b) {
          const x = a[key]
          const y = b[key]
          return ((x < y) ? -1 : ((x > y) ? 1 : 0))
        })
      },
      getReserved () {
        // 别人发给我的消息
        this.$fly.get(`https://www.wjxweb.cn:789/Message/all/1?type=fromTo&value=${this.sendId}-${this.myId}`)
          .then((res) => {
            this.reservedList = res.data.data
            // 时间格式化
            this.reservedList.forEach((value) => {
              value.date = formatTime(new Date(value.date))
            })
          })
      },
      getSend () {
        // 我发给别人的消息
        this.$fly.get(`https://www.wjxweb.cn:789/Message/all/1?type=fromTo&value=${this.myId}-${this.sendId}`)
          .then((res) => {
            this.sendList = res.data.data
            // 时间格式化
            this.sendList.forEach((value) => {
              value.date = formatTime(new Date(value.date))
            })
          })
      },
      handleList () {
        // 将我发送的消息和别人发给我的消息添加到一块
        this.allList = this._data.reservedList.concat(this._data.sendList)
      },
      sendMsg () {
        // 发送消息
        this.$fly.post('https://www.wjxweb.cn:789/Message', {
          'id': 0,
          'content': this.msg,
          'date': new Date(),
          'fromTo': this.myId + '-' + this.sendId,
          'toFrom': null,
          'fromWho': this.myId,
          'toWho': this.sendId
        })
          .then((res) => {
            console.log(res)
          })
          .catch((err) => {
            console.log(err)
          })
        this.msg = ''
      }
    }
  }
</script>

<style scoped>
  .footer{
    position: fixed;
    width: 100%;
    bottom: 0;
    background: #e3e7fe;
    text-align: center;
  }
  img {
    width: 85rpx;
    height: 85rpx;
    border-radius: 50%;
  }
 input {
   height: 36px;
   border-radius: 10px;
   border:3px solid #a2c6e7;
   background: #f6f7ff;
 }
  .displayRoom {
    position: absolute;
    width: 100%;
    text-align: center;
    /*background: linear-gradient(to bottom right, #63b5f0, #ffd3c7);*/
    background-color: #e6e5ff;
  }
  .displayBackground {
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: #e5e4fe;
  }
  .header {
    text-align: center;
    background-color: #26324b;
    color: white;
  }
  .msg_room {
    text-align: center;
  }
  .li1 {
    float: left;
    width: 15%;
    height: 100px;
  }
  .li2 {
    float: left;
    width: 70%;
    height: 100%;
  }
  .li3 {
    float: left;
    width: 15%;
    height: 100px;
  }
  .time_room {
    font-size: 15px;
  }
</style>
